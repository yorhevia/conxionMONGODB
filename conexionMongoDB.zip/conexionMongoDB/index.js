const express = require('express');
const app = express();
const mongoose = require('mongoose');
require('dotenv').config();
const port = process.env.PORT || 9000;

app.listen(port, ()=>console.log(
    'server listen on port',port
))

app.get('/',(req,res)=>{
    res.send('Bienvenido al servidor')
})

//conxiona mongoDB

mongoose
    .connect(process.env.MONGODB_URL)
    .then(()=>console.log('Te has conectado a MOngodb '))
    .catch((error)=>console.error(error))